package com.example.Spring.Boot.RestAPIs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApIsApplicationTests {

	@Test
	void contextLoads() {
	}

}
