package com.example.Spring.Boot.Prectice.Spring.Boot.Prectice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootPrecticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
