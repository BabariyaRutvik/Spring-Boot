package com.example.Spring.Boot.Prectice.Spring.Boot.Prectice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootPrecticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootPrecticeApplication.class, args);
	}

}
