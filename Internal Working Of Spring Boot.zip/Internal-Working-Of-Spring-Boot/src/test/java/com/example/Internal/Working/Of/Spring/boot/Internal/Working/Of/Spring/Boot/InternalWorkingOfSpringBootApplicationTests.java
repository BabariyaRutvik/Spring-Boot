package com.example.Internal.Working.Of.Spring.boot.Internal.Working.Of.Spring.Boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternalWorkingOfSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
