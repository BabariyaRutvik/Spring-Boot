package com.example.Spring.boot.StudentsData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentsDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
