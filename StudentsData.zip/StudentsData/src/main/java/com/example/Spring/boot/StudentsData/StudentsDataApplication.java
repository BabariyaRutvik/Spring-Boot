package com.example.Spring.boot.StudentsData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentsDataApplication.class, args);
	}

}
